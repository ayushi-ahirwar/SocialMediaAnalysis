
-- ============================================================================
-- SOCIAL MEDIA PROJECT
-- Submitted By: Ayushi Ahirwar
-- ============================================================================
 
-- ============================================================================
-- OBJECTIVE QUESTIONS
-- ============================================================================


 -- ============================================================================
-- Objective Question 1
-- 1.Are there any tables with duplicate or missing null values? If so, how would you handle them?
-- ============================================================================
  
  
  SELECT 
    username,
    COUNT(*) AS duplicate_count
FROM users
GROUP BY username
HAVING COUNT(*) > 1;

-- Check for NULL values

SELECT 'users' AS table_name, COUNT(*) AS null_count
FROM users
WHERE id IS NULL
   OR username IS NULL
   OR created_at IS NULL

UNION ALL

SELECT 'photos', COUNT(*)
FROM photos
WHERE id IS NULL
   OR image_url IS NULL
   OR user_id IS NULL
   OR created_dat IS NULL

UNION ALL

SELECT 'comments', COUNT(*)
FROM comments
WHERE id IS NULL
   OR comment_text IS NULL
   OR user_id IS NULL
   OR photo_id IS NULL
   OR created_at IS NULL

UNION ALL

SELECT 'likes', COUNT(*)
FROM likes
WHERE user_id IS NULL
   OR photo_id IS NULL
   OR created_at IS NULL

UNION ALL

SELECT 'follows', COUNT(*)
FROM follows
WHERE follower_id IS NULL
   OR followee_id IS NULL
   OR created_at IS NULL

UNION ALL

SELECT 'tags', COUNT(*)
FROM tags
WHERE id IS NULL
   OR tag_name IS NULL
   OR created_at IS NULL

UNION ALL

SELECT 'photo_tags', COUNT(*)
FROM photo_tags
WHERE photo_id IS NULL
   OR tag_id IS NULL;
   
   
-- ============================================================================
-- Objective Question 2
-- 2.What is the distribution of user activity levels (e.g., number of posts, likes, comments) across the user base?
-- ============================================================================
   

SELECT
    u.id,
    u.username,
    COUNT(DISTINCT p.id) AS total_posts,
    COUNT(DISTINCT l.photo_id) AS total_likes_given,
    COUNT(DISTINCT c.id) AS total_comments_made,
    (
        COUNT(DISTINCT p.id)
        + COUNT(DISTINCT l.photo_id)
        + COUNT(DISTINCT c.id)
    ) AS total_activity
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON u.id = l.user_id
LEFT JOIN comments c
    ON u.id = c.user_id
GROUP BY
    u.id,
    u.username
ORDER BY
    total_activity DESC;
    
    
-- ============================================================================
-- Objective Question 3
-- 3.Calculate the average number of tags per post (photo_tags and photos tables).
-- ============================================================================


SELECT 
    ROUND(
        COUNT(pt.tag_id) / (SELECT COUNT(*) FROM photos),
        2
    ) AS average_tags_per_post
FROM photo_tags pt;    


-- ============================================================================
-- Objective Question 4
-- 4.Identify the top users with the highest engagement rates (likes, comments) on their posts and rank them.
-- ============================================================================


WITH post_engagement AS (
    SELECT
        p.id AS photo_id,
        p.user_id,
        COUNT(DISTINCT l.user_id) AS likes,
        COUNT(DISTINCT c.id) AS comments
    FROM photos p
    LEFT JOIN likes l
        ON p.id = l.photo_id
    LEFT JOIN comments c
        ON p.id = c.photo_id
    GROUP BY
        p.id,
        p.user_id
),

user_engagement AS (
    SELECT
        u.id,
        u.username,
        COUNT(pe.photo_id) AS total_posts,
        SUM(pe.likes) AS total_likes,
        SUM(pe.comments) AS total_comments,
        SUM(pe.likes + pe.comments) AS total_engagement,
        AVG(pe.likes + pe.comments) AS engagement_rate
    FROM users u
    JOIN post_engagement pe
        ON u.id = pe.user_id
    GROUP BY
        u.id,
        u.username
)

SELECT
    id,
    username,
    total_posts,
    total_likes,
    total_comments,
    total_engagement,
    ROUND(engagement_rate, 2) AS engagement_rate,
    DENSE_RANK() OVER (
        ORDER BY engagement_rate DESC
    ) AS engagement_rank
FROM user_engagement
ORDER BY
    engagement_rank,
    username;
    
    
-- ============================================================================
-- Objective Question 5
-- Which users have the highest number of followers and followings?
-- ============================================================================


WITH follower_counts AS (
    SELECT
        followee_id AS user_id,
        COUNT(*) AS followers
    FROM follows
    GROUP BY followee_id
),

following_counts AS (
    SELECT
        follower_id AS user_id,
        COUNT(*) AS following
    FROM follows
    GROUP BY follower_id
)

SELECT
    u.id,
    u.username,
    COALESCE(fc.followers, 0) AS followers,
    COALESCE(fgc.following, 0) AS following
FROM users u
LEFT JOIN follower_counts fc
    ON u.id = fc.user_id
LEFT JOIN following_counts fgc
    ON u.id = fgc.user_id
ORDER BY
    followers DESC,
    following DESC;
    
    
-- ============================================================================
-- Objective Question 6
-- Calculate the average engagement rate (likes, comments) per post for each user.
-- ============================================================================    
    

WITH post_engagement AS (
    SELECT
        p.id AS photo_id,
        p.user_id,
        COUNT(DISTINCT l.user_id) AS likes,
        COUNT(DISTINCT c.id) AS comments
    FROM photos p
    LEFT JOIN likes l
        ON p.id = l.photo_id
    LEFT JOIN comments c
        ON p.id = c.photo_id
    GROUP BY
        p.id,
        p.user_id
)

SELECT
    u.id,
    u.username,
    COUNT(pe.photo_id) AS total_posts,
    ROUND(AVG(pe.likes), 2) AS average_likes_per_post,
    ROUND(AVG(pe.comments), 2) AS average_comments_per_post,
    ROUND(AVG(pe.likes + pe.comments), 2) AS average_engagement_per_post
FROM users u
LEFT JOIN post_engagement pe
    ON u.id = pe.user_id
GROUP BY
    u.id,
    u.username
ORDER BY
    average_engagement_per_post DESC;
    
    
-- ============================================================================
-- Objective Question 7
-- Get the list of users who have never liked any post (users and likes tables)
-- ============================================================================


SELECT
    u.id,
    u.username
FROM users u
LEFT JOIN likes l
    ON u.id = l.user_id
WHERE l.user_id IS NULL
ORDER BY u.id;


-- ============================================================================
-- Objective Question 8
-- How can you leverage user-generated content (posts, hashtags, photo tags) to create more personalized and engaging ad campaigns?
-- ============================================================================

SELECT

t.tag_name AS Hashtag,

COUNT(DISTINCT pt.photo_id) AS Total_Posts,

COUNT(l.photo_id) AS Total_Likes,

ROUND(COUNT(l.photo_id) / COUNT(DISTINCT pt.photo_id), 2) AS Avg_Likes_Per_Post

FROM tags t

JOIN photo_tags pt ON t.id = pt.tag_id

LEFT JOIN likes l ON pt.photo_id = l.photo_id

GROUP BY t.tag_name

ORDER BY Total_Likes DESC, Total_Posts DESC

LIMIT 10;

    
    
-- ============================================================================
-- Objective Question 9
-- Are there any correlations between user activity levels and specific
-- content types (e.g., photos, videos, reels)? How can this information
-- guide content creation and curation strategies?
-- ============================================================================
    

SELECT
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.photo_id) AS likes,
    COUNT(DISTINCT c.id) AS comments
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON u.id = l.user_id
LEFT JOIN comments c
    ON u.id = c.user_id
GROUP BY u.id, u.username
ORDER BY posts DESC;


-- ============================================================================
-- Objective Question 10
-- Calculate the total number of likes, comments, and photo tags for each user.
-- ============================================================================


SELECT
    u.id,
    u.username,

    (SELECT COUNT(*)
     FROM likes l
     JOIN photos p ON l.photo_id = p.id
     WHERE p.user_id = u.id) AS total_likes,

    (SELECT COUNT(*)
     FROM comments c
     JOIN photos p ON c.photo_id = p.id
     WHERE p.user_id = u.id) AS total_comments,

    (SELECT COUNT(*)
     FROM photo_tags pt
     JOIN photos p ON pt.photo_id = p.id
     WHERE p.user_id = u.id) AS total_photo_tags

FROM users u
ORDER BY u.id;


-- ============================================================================
-- Objective Question 11
-- Rank users based on their total engagement (likes, comments, shares) over a month.
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT l.photo_id) AS likes,
    COUNT(DISTINCT c.id) AS comments,
    (
        COUNT(DISTINCT l.photo_id) +
        COUNT(DISTINCT c.id)
    ) AS total_engagement
FROM users u
LEFT JOIN likes l
    ON u.id = l.user_id
LEFT JOIN comments c
    ON u.id = c.user_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC;


-- ============================================================================
-- Objective Question 12
-- Retrieve the hashtags that have been used in posts with the highest average
-- number of likes. Use a CTE to calculate the average likes for each
-- hashtag first.
-- ============================================================================


WITH hashtag_likes AS (
    SELECT
        t.tag_name,
        AVG(likes_count) AS average_likes
    FROM tags t
    JOIN photo_tags pt
        ON t.id = pt.tag_id
    JOIN (
        SELECT
            p.id AS photo_id,
            COUNT(l.user_id) AS likes_count
        FROM photos p
        LEFT JOIN likes l
            ON p.id = l.photo_id
        GROUP BY p.id
    ) x
        ON pt.photo_id = x.photo_id
    GROUP BY t.tag_name
)

SELECT
    tag_name,
    ROUND(average_likes, 2) AS average_likes
FROM hashtag_likes
WHERE average_likes = (
    SELECT MAX(average_likes)
    FROM hashtag_likes
);


-- ============================================================================
-- Objective Question 13
-- Retrieve the users who have started following someone after being followed by that person
-- ============================================================================


SELECT DISTINCT
     u.id,
     u.username
FROM users u 
JOIN follows f1
     ON u.id = f1.follower_id
JOIN follows f2
     ON f1.follower_id =
f2.followee_id
    AND f1.followee_id =
f2.follower_id 
ORDER BY u.id;





-- ============================================================================
-- SUBJECTIVE QUESTIONS
-- ============================================================================


-- ============================================================================
-- Subjective Question 1
-- Based on user engagement and activity levels, which users would you
-- consider the most loyal or valuable? How would you reward or incentivize
-- these users?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.photo_id) AS likes_given,
    COUNT(DISTINCT c.id) AS comments_made,
    (
        COUNT(DISTINCT p.id)
        + COUNT(DISTINCT l.photo_id)
        + COUNT(DISTINCT c.id)
    ) AS total_activity
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON u.id = l.user_id
LEFT JOIN comments c
    ON u.id = c.user_id
GROUP BY u.id, u.username
ORDER BY total_activity DESC
LIMIT 10;


-- ============================================================================
-- Subjective Question 2
-- For inactive users, what strategies would you recommend to re-engage them
-- and encourage them to start posting or engaging again?
-- ============================================================================


SELECT

u.id,

u.username,

COALESCE(p.Total_Posts, 0) AS Total_Posts,

COALESCE(l.Total_Likes_Given, 0) AS Total_Likes_Given,

COALESCE(c.Total_Comments_Made, 0) AS Total_Comments_Made,

COALESCE(f.Total_Following, 0) AS Total_Following

FROM users u

LEFT JOIN (

SELECT

user_id,

COUNT(*) AS Total_Posts

FROM photos

GROUP BY user_id

) p

ON u.id = p.user_id

LEFT JOIN (

SELECT

user_id,

COUNT(*) AS Total_Likes_Given

FROM likes

GROUP BY user_id

) l

ON u.id = l.user_id

LEFT JOIN (

SELECT

user_id,

COUNT(*) AS Total_Comments_Made

FROM comments

GROUP BY user_id

) c

ON u.id = c.user_id

LEFT JOIN (

SELECT

follower_id,

COUNT(*) AS Total_Following

FROM follows

GROUP BY follower_id

) f

ON u.id = f.follower_id

WHERE

COALESCE(p.Total_Posts, 0) = 0

AND COALESCE(l.Total_Likes_Given, 0) = 0

AND COALESCE(c.Total_Comments_Made, 0) = 0

ORDER BY

u.id;



-- ============================================================================
-- Subjective Question 3
-- Which hashtags or content topics have the highest engagement rates? How can
-- this information guide content strategy and ad campaigns?
-- ============================================================================


WITH Hashtag_Engagement AS (

SELECT

t.id AS Tag_ID,

t.tag_name AS Hashtag,

COUNT(DISTINCT l.user_id, l.photo_id) AS Total_Likes,

COUNT(DISTINCT c.id) AS Total_Comments,

ROUND(

(

COUNT(DISTINCT l.user_id, l.photo_id) +

COUNT(DISTINCT c.id)

) /

COUNT(DISTINCT pt.photo_id),

2

) AS Avg_Engagement_Per_Post

FROM tags t

INNER JOIN photo_tags pt

ON t.id = pt.tag_id

LEFT JOIN likes l

ON pt.photo_id = l.photo_id

LEFT JOIN comments c

ON pt.photo_id = c.photo_id

GROUP BY

t.id,

t.tag_name

)

SELECT

Tag_ID,

Hashtag,

Total_Likes,

Total_Comments,

Avg_Engagement_Per_Post

FROM Hashtag_Engagement

ORDER BY Avg_Engagement_Per_Post DESC;

-- ============================================================================
-- Subjective Question 4
-- Are there any patterns or trends in user engagement based on demographics
-- (age, location, gender) or posting times? How can these insights inform
-- targeted marketing campaigns?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.user_id) AS likes,
    COUNT(DISTINCT c.id) AS comments
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON p.id = l.photo_id
LEFT JOIN comments c
    ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY likes DESC;


-- ============================================================================
-- Subjective Question 5
-- Based on follower counts and engagement rates, which users would be ideal
-- candidates for influencer marketing campaigns? How would you approach
-- and collaborate with these influencers?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT f.follower_id) AS followers
FROM users u
LEFT JOIN follows f
    ON u.id = f.followee_id
GROUP BY u.id, u.username
ORDER BY followers DESC
LIMIT 10;


-- ============================================================================
-- Subjective Question 6
-- Based on user behavior and engagement data, how would you segment the user
-- base for targeted marketing campaigns or personalized recommendations?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.photo_id) AS likes,
    COUNT(DISTINCT c.id) AS comments,
    CASE
        WHEN COUNT(DISTINCT p.id) >= 3 THEN 'Highly Active'
        WHEN COUNT(DISTINCT p.id) >= 1 THEN 'Active'
        ELSE 'Inactive'
    END AS user_segment
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON p.id = l.photo_id
LEFT JOIN comments c
    ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY posts DESC;


-- ============================================================================
-- Subjective Question 7
-- If data on ad campaigns (impressions, clicks, conversions) is available,
-- how would you measure their effectiveness and optimize future campaigns?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT l.user_id) AS likes,
    COUNT(DISTINCT c.id) AS comments,
    (COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) AS total_engagement
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON p.id = l.photo_id
LEFT JOIN comments c
    ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY total_engagement DESC
LIMIT 10;


-- ============================================================================
-- Subjective Question 8
-- How can you use user activity data to identify potential brand ambassadors
-- or advocates who could help promote Instagram's initiatives or events?
-- ============================================================================


SELECT
    u.username,
    COUNT(DISTINCT p.id) AS posts,
    COUNT(DISTINCT l.user_id) AS likes,
    COUNT(DISTINCT c.id) AS comments
FROM users u
LEFT JOIN photos p
    ON u.id = p.user_id
LEFT JOIN likes l
    ON p.id = l.photo_id
LEFT JOIN comments c
    ON p.id = c.photo_id
GROUP BY u.id, u.username
ORDER BY likes DESC, comments DESC
LIMIT 10;


-- ============================================================================
-- Subjective Question 9
-- How would you approach this problem, if the objective and subjective questions weren't given?
-- ============================================================================


-- Approach:
-- 1. Understand the business problem and available data.
-- 2. Explore and clean the data.
-- 3. Identify important metrics and user activity patterns.
-- 4. Analyze the data to find useful insights.
-- 5. Present the findings and suggest data-driven actions.


-- ============================================================================
-- Subjective Question 10
-- Assuming there's a "User_Interactions" table tracking user engagements, how
-- can you update the "Engagement_Type" column to change all instances of
-- "Like" to "Heart" to align with Instagram's terminology?
-- ============================================================================


-- Approach:
-- Update the Engagement_Type column in the User_Interactions table.
-- Replace 'Like' with 'Heart' for all matching records.
-- This will align the engagement terminology with Instagram.



/* ===================================== END OF FILE ===================================== */






